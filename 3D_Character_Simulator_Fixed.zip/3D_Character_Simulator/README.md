# 3D Character Simulator

Starter Android project for a touch-controlled 3D model viewer/simulator.

## Features in this starter
- Opens into an empty 3D studio.
- Import `.glb` / `.gltf` files from Android storage using the file picker (for `.gltf`, select the `.bin` and texture files together, or use a ZIP).
- Import a `.zip` containing `.glb` model files (the app reads those files from the ZIP).
- Select among imported models.
- Touch joystick movement, drag-to-rotate camera, zoom buttons.
- Studio / simple open-world scene toggle.
- Android APK build using GitHub Actions.

## Build on GitHub from an Android phone
1. Create a GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself) into the repository root.
3. Open **Actions** and run **Build 3D Character Simulator APK**.
4. When the workflow finishes, open the run and download the `3d-character-simulator-debug-apk` artifact.

## Notes
- The app is served inside the WebView via `WebViewAssetLoader` (https://appassets.androidplatform.net) because ES modules do not work from `file://`.
- Three.js and its GLTF loader are bundled into the APK during the GitHub Actions build, so the viewer itself can work offline.
- The imported model is selected from Android storage. GLTF files that reference separate external textures/buffers may need to be kept together or packaged as `.glb`.
- FBX/OBJ are not included in this first version. `.glb` is recommended. ZIP import supports `.glb` and `.gltf` (with its resources) inside the archive. Draco/Meshopt-compressed GLB are supported.
- This is a starter project. Performance depends on the model complexity and the Android device.
