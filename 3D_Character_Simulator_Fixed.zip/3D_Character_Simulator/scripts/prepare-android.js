const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const dest = path.join(root, 'android', 'app', 'src', 'main', 'assets', 'web');
const three = path.join(root, 'node_modules', 'three');
const jsm = path.join(three, 'examples', 'jsm');
const vendor = path.join(dest, 'vendor');

function must(p) {
  if (!fs.existsSync(p)) throw new Error('File tidak ditemukan: ' + p + ' (jalankan "npm install" dulu)');
  return p;
}
function copy(src, dst, optional = false) {
  if (!fs.existsSync(src)) {
    if (optional) { console.warn('Lewati (opsional):', src); return; }
    must(src);
  }
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.cpSync(src, dst, { recursive: true });
}

fs.rmSync(dest, { recursive: true, force: true });   // buang sisa build lama
fs.mkdirSync(dest, { recursive: true });

for (const name of ['index.html', 'app.js', 'style.css']) copy(path.join(root, 'web', name), path.join(dest, name));

// three.js (r171+ memecah build menjadi three.module.js + three.core.js; salin keduanya bila ada)
copy(path.join(three, 'build', 'three.module.js'), path.join(vendor, 'three.module.js'));
copy(path.join(three, 'build', 'three.core.js'), path.join(vendor, 'three.core.js'), true);

// GLTFLoader + dependensinya
copy(path.join(jsm, 'loaders', 'GLTFLoader.js'), path.join(vendor, 'loaders', 'GLTFLoader.js'));
copy(path.join(jsm, 'utils', 'BufferGeometryUtils.js'), path.join(vendor, 'utils', 'BufferGeometryUtils.js'));

// Dekoder opsional untuk GLB terkompresi (Draco / Meshopt) -- banyak model karakter memakainya
copy(path.join(jsm, 'loaders', 'DRACOLoader.js'), path.join(vendor, 'loaders', 'DRACOLoader.js'), true);
copy(path.join(jsm, 'libs', 'draco', 'gltf'), path.join(vendor, 'draco', 'gltf'), true);
copy(path.join(jsm, 'libs', 'meshopt_decoder.module.js'), path.join(vendor, 'libs', 'meshopt_decoder.module.js'), true);

copy(path.join(root, 'node_modules', 'jszip', 'dist', 'jszip.min.js'), path.join(vendor, 'jszip.min.js'));
console.log('Bundled web app into Android assets.');
